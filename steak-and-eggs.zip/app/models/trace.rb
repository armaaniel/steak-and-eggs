class Trace < ApplicationRecord
end

