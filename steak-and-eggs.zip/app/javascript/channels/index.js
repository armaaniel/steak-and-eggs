import { createConsumer } from "@rails/actioncable"
export default createConsumer()
