# README

git clone this repo, 

navigate to this folder in your terminal

type bundle install
(you need ruby installed)

type npm install 
(you need node.js installed)

type rails s
(you need rails installed)

open up http://localhost:3000/

sign up

should be good
